package ostrander.ostrander_deck_lab7;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Deck 
{
    private List<Card> deckOfCards;

    //Constructor
    public Deck()
    {
        createDeck();        
    }


    //CreateDeck - creates a new deckOfCards of unshuffled cards
    public void createDeck()
    {
        deckOfCards = new ArrayList<>();
        
        for(int i = 1; i < 5; i++)
        {
            for(int x = 2; x < 15; x++)
            {
                //Add a new card to deckOfCards with suit i and value x.
                deckOfCards.add(new Card(i, x));
            }
        }  
    }
    
    
    //Deal method - Shuffles deckOfCards
    public void shuffleDeck()
    {
        List<Card> shuffle = new ArrayList<>(); //used to hold shuffled cards
        
        Random random = new Random(); //To truly randomly select cards in shuffle
        int index; //Holds random value
        
        while(!deckOfCards.isEmpty())
        {
            index = random.nextInt(deckOfCards.size()); //Had to simplify to make work - worked in tests
            shuffle.add(deckOfCards.get(index));
            deckOfCards.remove(index);
        }
 
        deckOfCards = shuffle;
     
    }
    
    
    public Card deal()
    {
        //return card on top of deckOfCards
        Card topCard = deckOfCards.get(0);
        deckOfCards.remove(0); //remove card from deckOfCards.
        
        return topCard;
    }
    
}
