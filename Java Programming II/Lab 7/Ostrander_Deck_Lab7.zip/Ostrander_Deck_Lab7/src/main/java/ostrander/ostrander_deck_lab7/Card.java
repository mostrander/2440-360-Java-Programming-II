package ostrander.ostrander_deck_lab7;


public class Card 
{
    String suit;  //Suit of the card, i.e. Club or Heart
    String value; //Value of the card, i.e. 4, Ace, King, etc.
    
    //constructor
    public Card(int suitNum, int cardValue)
    {
        //Determine suit for card
        switch(suitNum)
        {
            case 1:
                suit = "Clubs";
                break;
            case 2:
                suit = "Spades";
                break;
            case 3:
                suit = "Hearts";
                break;
            case 4:
                suit = "Diamonds";
                break;
            default:
                break;
        }
        
        //Determine the value of card in suit
        if (cardValue > 10)
        {
            switch(cardValue)
            {
                case 11:
                    value = "Jack";
                    break;
                case 12:
                    value = "Queen";
                    break;
                case 13:
                    value = "King";
                    break;
                case 14:
                    value = "Ace";
                    break;
                default:
                    break;
            }
            
        }
        else
        {
            value = String.valueOf(cardValue);
        }   
    }
    
    //Obtains corresponding file name for card
    public String getCardName()
    {
        return "/" + suit + "/" + value + ".png";  //Will be used when I figure out how to get files from program folder
        //return value + ".png"; //Test from DESKTOP
    }
    
}
