package ostrander.ostrander_deck_lab7;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



public class App extends Application 
{
    //Image objects that will be modified while program runs
    ImageView card1View, card2View, card3View, card4View, card5View, 
            card6View, card7View, card8View, card9View, card10View;
    
    //Create buttons
    Button dealButton = new Button("Deal");
    Button resetButton = new Button("Reset");
    
    //Players
    Player player1;
    Player player2;
    
    //Deck built
    Deck deck;
    

    @Override
    public void start(Stage stage) {

        //Create labels to indicate players
        Label player1Label = new Label("Player 1");
        Label player2Label = new Label("Player 2");
        
        player1Label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold");
        player2Label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold");
        
        
        //Create player objects (2)
        player1 = new Player();
        player2 = new Player();
        
        //Create deck object (1) - contains 52 cards
        deck = new Deck();
        
        //Create Card objects
        Image card1, card2, card3, card4, card5, card6, card7, card8, card9, card10;
        
        //Testing card look - set cards' images
        card1 = new Image(getClass().getResourceAsStream("/back.png")); //this works
//        card1 = new Image("file:..\\deck-Images\\deck\\back.png");

        //Setup all cards in hand to show backs
        card2 = card3 = card4 = card5 = card6 = card7 = card8 = card9 = card10 = card1;
        
        
        //Create ImageView to hold player 1 card images
        card1View = new ImageView(card1);
        card2View = new ImageView(card2);
        card3View = new ImageView(card3);
        card4View = new ImageView(card4);
        card5View = new ImageView(card5);
        
        
        //Create ImageView to hold player 2 card images
        card6View = new ImageView(card6);
        card7View = new ImageView(card7);
        card8View = new ImageView(card8);
        card9View = new ImageView(card9);
        card10View = new ImageView(card10);
        
        
        //Create HBox containers to hold dealt cards - player 1
        HBox player1Hand = new HBox(10, card1View, card2View, card3View, card4View, card5View);
        
        
        //Create HBox containers to hold dealt cards - player 2
        HBox player2Hand = new HBox(10, card6View, card7View, card8View, card9View, card10View);
        
        
        //Create HBox to contain buttons
        HBox buttonDisplay = new HBox(20, dealButton, resetButton);
        
        buttonDisplay.setAlignment(Pos.CENTER);
        buttonDisplay.setPadding(new Insets(10));
        buttonDisplay.setStyle("-fx-font-size: 14px");
        
        
        //Set button actions.
        dealButton.setOnAction( new dealButtonHandler() );
        resetButton.setOnAction( new resetButtonHandler() );
        
        resetButton.setDisable(true); //Disabled when program is launched

        
        //Create VBox to hold GUI elements
        VBox userInterface = new VBox(10, player1Label, player1Hand, 
                            buttonDisplay, player2Hand, player2Label);
        
        userInterface.setPadding(new Insets(10));
        userInterface.setAlignment(Pos.CENTER);
        
        
        //Set and display the scene
        Scene game = new Scene(userInterface);
        stage.setScene(game);
        stage.show();
    }

    
    public static void main(String[] args) {
        launch();
    }

    
    //Program methods
  
    class dealButtonHandler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle (ActionEvent event)
        {
            
            try
            {
                
                deck.shuffleDeck();
        
                for(int i = 0; i < 5; i++)
                {
                    player1.addCard(deck.deal());
                    player2.addCard(deck.deal());
                }

                
                //Show cards
                String fullPath; //mainPath + cardPath
                Image newImg;

                //Player 1 cards, 1 - 5
                fullPath = player1.retrieveCard(0);
                newImg = new Image(getClass().getResourceAsStream(fullPath)); //THIS IS THE WAY!!!!
                card1View.setImage(newImg);
                
                
                
                
                
                
                

                fullPath = player1.retrieveCard(1);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card2View.setImage(newImg); 

                fullPath = player1.retrieveCard(2);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card3View.setImage(newImg); 

                fullPath = player1.retrieveCard(3);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card4View.setImage(newImg); 

                fullPath = player1.retrieveCard(4);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card5View.setImage(newImg); 


                //Player 2 cards, 6 - 10
                fullPath = player2.retrieveCard(0);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card6View.setImage(newImg); 

                fullPath = player2.retrieveCard(1);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card7View.setImage(newImg); 

                fullPath = player2.retrieveCard(2);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card8View.setImage(newImg); 

                fullPath = player2.retrieveCard(3);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card9View.setImage(newImg); 

                fullPath = player2.retrieveCard(4);
                newImg = new Image(getClass().getResourceAsStream(fullPath));
                card10View.setImage(newImg); 


                resetButton.setDisable(false);
                dealButton.setDisable(true);
                
            }
            catch (Exception e)
            {
                //error occurred
            }
            
            
        }
        
    }
    

    class resetButtonHandler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle (ActionEvent event)
        {
            
            try
            {
                //Clear player hands of cards
                player1.clearHand();
                player2.clearHand();
                
                //Reset all of the card views to Back.png
                Image image = new Image(getClass().getResourceAsStream("/back.png"));
                card1View.setImage(image);
                card2View.setImage(image);
                card3View.setImage(image);
                card4View.setImage(image);
                card5View.setImage(image);
                card6View.setImage(image);
                card7View.setImage(image);
                card8View.setImage(image);
                card9View.setImage(image);
                card10View.setImage(image);

                //Reset the deck - reinitialize 
                deck.createDeck();
                
                resetButton.setDisable(true);
                dealButton.setDisable(false);
                
            }
            catch (Exception e)
            {
                //An error occurred
            }
   
        }
        
        
        
    }
    
    
    
}