package ostrander.ostrander_deck_lab7;

import java.util.ArrayList;
import java.util.List;


public class Player 
{
    //List that will contain the player's current hand of cards
    private List<Card> hand;
    
    //Constructor
    public Player()
    {
        hand = new ArrayList<>(); //create hand.
    }
    
    //Add new card to hand
    public void addCard(Card x)
    {
        hand.add(x);
    }
    
    //retrieve specified card from hand
    public String retrieveCard(int x)
    {
        return hand.get(x).getCardName();
    }
    
    //Clears all cards/elements from hand
    public void clearHand()
    {
        hand.clear();
    }
    
}
