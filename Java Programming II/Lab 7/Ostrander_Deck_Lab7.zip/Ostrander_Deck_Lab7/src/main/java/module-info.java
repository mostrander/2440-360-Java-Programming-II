module ostrander.ostrander_deck_lab7 {
    requires javafx.controls;
    exports ostrander.ostrander_deck_lab7;
}
