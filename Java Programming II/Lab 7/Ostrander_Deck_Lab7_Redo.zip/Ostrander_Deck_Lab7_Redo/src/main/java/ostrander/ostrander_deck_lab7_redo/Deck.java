package ostrander.ostrander_deck_lab7_redo;

import static java.util.Collections.shuffle;
import java.util.Stack;


public class Deck 
{
    private Stack<Card> deckOfCards; //Stack version

    //Constructor
    public Deck()
    {
        createDeck();        
    }


    //CreateDeck - creates a new deckOfCards of unshuffled cards
    public void createDeck()
    {
        deckOfCards = new Stack();
        //deckOfCards = new ArrayList<>();
        
        for(int i = 1; i < 5; i++)
        {
            for(int x = 2; x < 15; x++)
            {
                //Add a new card to deckOfCards with suit i and value x.
                deckOfCards.push(new Card(i, x));
            }
        }  
    }
    
    
    //Deal method - Shuffles deckOfCards
    public void shuffleDeck()
    {
        //Test
        shuffle(deckOfCards);
    }
    
    
    public Card deal()
    {
        //return card on top of deckOfCards
        Card topCard = deckOfCards.pop();
        return topCard;
    }
}
