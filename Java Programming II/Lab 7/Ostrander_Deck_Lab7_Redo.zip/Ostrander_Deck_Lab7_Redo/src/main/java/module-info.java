module ostrander.ostrander_deck_lab7_redo {
    requires javafx.controls;
    exports ostrander.ostrander_deck_lab7_redo;
}
