package ostrander;

import java.util.ArrayList;

/**
 *
 * @author ostra
 */
public class madLib implements java.io.Serializable
{
    private String madLibText;
    
    private String noun;
    private String profession;
    private String time;
    private String difficulty;
    private String verb1;
    private String color;
    private String verb2;

    public String getNoun() {
        return noun;
    }

    public void setNoun(String noun) {
        this.noun = noun;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getVerb1() {
        return verb1;
    }

    public void setVerb1(String verb) {
        this.verb1 = verb;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getVerb2() {
        return verb2;
    }

    public void setVerb2(String verb2) {
        this.verb2 = verb2;
        setMadLibText();
    }
    
    
    
    //Constructor is allowed to set default values.
    public madLib() { }

    public String getMadLibText() 
    {  return madLibText;  }

    public void setMadLibText(String madLibText) 
    {  this.madLibText = madLibText;  }
    
    
    public void setMadLibText(ArrayList<String> values) 
    {
//        noun = verb1 = verb2 = time = profession = difficulty = color = "";
//        setMadLibText();
        
        madLibText = "There once was a " + values.get(2) + " who dreamed of becoming a " + values.get(3) + "."
                + "The " + values.get(2) + " would " + values.get(5) + " all day long until the " + values.get(2) + "‘s face turned " + values.get(0) + ". "
                + "After practicing how to " + values.get(0) + " for 3 " + values.get(4) + "s, "
                + "the " + values.get(2) + " entered a competition to become a " + values.get(3) + ". The competition was " + values.get(1) + ". ";
    }
    
    //Automatically fills in the text based on string properties.
    public void setMadLibText()
    {
        madLibText = "There once was a " + noun + " who dreamed of becoming a " + profession + "."
                + "The " + noun + " would " + verb1 + " all day long until the " + noun + "‘s face turned " + color + ". "
                + "After practicing how to " + verb2 + " for 3 " + time + "s, "
                + "the " + noun + " entered a competition to become a " + profession + ". The competition was " + difficulty + ". ";
    }
    
    
    public String toString()
    {  return madLibText;  }
    
}
