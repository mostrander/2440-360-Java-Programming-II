package ostrander.ostrander_lab4_javafx;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    //Needed to display information
    private TextField textReadOnly1;
    private TextField textReadOnly2;
    
    //Needed to obtain user input
    TextField userInput1;
    ComboBox monthComboBox;
    ComboBox numComboBox;
    
    
    @Override
    public void start(Stage stage) {
//        var javaVersion = SystemInfo.javaVersion();
//        var javafxVersion = SystemInfo.javafxVersion();
        
        textReadOnly1 = new TextField(); //Section 1, readonly display field
        textReadOnly1.setEditable(false); //make read only.
        
        textReadOnly2 = new TextField(); //Section 2, readonly display field
        textReadOnly2.setEditable(false); //make read only.
        
        userInput1 = new TextField(); //Section 1, field for user input
        
        
        //Create list for month options, create combobox using list, for section 2
        ObservableList<String> monthOptions = 
        FXCollections.observableArrayList(
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
        );
        
        monthComboBox = new ComboBox(monthOptions);
        
        
        //Create list containing month numbers, create combobox, for section 2
        ObservableList<String> numberOptions = 
        FXCollections.observableArrayList(
        "1","2","3","4","5","6","7","8","9","10","11","12"
        );
        
        numComboBox = new ComboBox(numberOptions);
        
        
        //Buttons for each section
        Button submitInput1 = new Button("Submit"); //section 1
        
        //This works
        //submitInput1.setStyle("-fx-background-color: black; -fx-text-fill: white");
        
//        submitInput1.getStyleClass().add("black-button"); //does not work
//        submitInput1.setId("button-black"); 
        submitInput1.setOnAction(new SubmitButtonSection1Handler());
        
        
        Button submitInput2 = new Button("Submit"); //section 2
        submitInput2.setOnAction(new SubmitButtonSection2Handler());
        
        //Create layout containers
        //Section 1 - hbox
        HBox userInputSection1 = new HBox(35, userInput1, submitInput1);
        userInputSection1.setAlignment(Pos.CENTER);
        
        //Comine layouts for section 1
        VBox section1 = new VBox(10,textReadOnly1, userInputSection1);
        section1.setStyle("-fx-padding: 15px; -fx-background-color: #b582c2");
        
        //Name section 1 layout for CSS use later
        section1.setId("section-1");
        
        //section 2 - hbox
        HBox userInputSection2 = new HBox(10, numComboBox, monthComboBox, submitInput2);
        userInputSection2.setAlignment(Pos.CENTER);
        
        //Combine layouts for section 2
        VBox section2 = new VBox(10, textReadOnly2, userInputSection2);
        section2.setStyle("-fx-padding: 15px; -fx-background-color: #966ca1");
        
        //Name section 2 layout for CSS use later
        section2.setId("section-2");
        
        
        //Comine sections
        VBox monthDisplayCombined = new VBox(section1, section2);
        
        
        //Add to scene
        Scene scene = new Scene(monthDisplayCombined);
        scene.getStylesheets().add("monthStyles.css");
        
        stage.setScene(scene);
        stage.show();
        

    }

    public static void main(String[] args) {
        launch();
    }
    
    
    class SubmitButtonSection1Handler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle (ActionEvent event)
        {
            Month monthAttempt1; //Prepare month object
            String input = userInput1.getText(); //Obtain user input
            int numInput = -1; //Invalid input, prepare for number input

            
            if(input.isBlank())
            {
                monthAttempt1 = new Month(); //default constructor
            }
            else
            {
                try
                {
                    //Try to retrieve integer value from string
                    numInput = Integer.parseInt(input);
                    
                    //If that does NOT fail, use the int constructor
                    monthAttempt1 = new Month(numInput);
                    
                }
                catch(Exception e)
                {
                    //Else, use the String constructor
                    monthAttempt1 = new Month(input);
                }
                
            }
            
            
            //Determine if monthAttempt contains a valid input
            if(monthAttempt1.printMonthName() != null)
            {
                textReadOnly1.setText(monthAttempt1.toString());
            }
            else
            {
                textReadOnly1.setText("Unrecognized text entry. "
                        + "Please enter the number or name associated with the desired month.");
            }
            
        }
        
        
    }
    
    
    class SubmitButtonSection2Handler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle (ActionEvent event)
        {
            Month monthSelected1; //Prepare month objects. For int
            Month monthSelected2; //For String
            
            //Get the combobox values selected
            String selectedNum = (String) numComboBox.getValue();
            String selectedMonth = (String)monthComboBox.getValue();
            
            //Verify user selects from both comboboxes.
            if(selectedNum == null || selectedMonth == null)
            {
                textReadOnly2.setText("Invalid selections.");
            }
            else
            {
                try
                {
                  int monthNum = Integer.parseInt(selectedNum);  
                  
                  //Create month objects
                  Month month1 = new Month(monthNum);
                  Month month2 = new Month(selectedMonth);
                  
                  //compare the month values and update read only field.
                  textReadOnly2.setText(month1.monthComparison(month2));
                }
                catch(Exception e)
                {
                    textReadOnly2.setText("Unexpected error occurred.");
                }
 
            }
            
        }
        

    }
    
    
    
}