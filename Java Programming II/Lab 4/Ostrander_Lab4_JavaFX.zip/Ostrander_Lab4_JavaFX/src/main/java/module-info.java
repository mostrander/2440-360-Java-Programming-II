module ostrander.ostrander_lab4_javafx {
    requires javafx.controls;
    exports ostrander.ostrander_lab4_javafx;
}
