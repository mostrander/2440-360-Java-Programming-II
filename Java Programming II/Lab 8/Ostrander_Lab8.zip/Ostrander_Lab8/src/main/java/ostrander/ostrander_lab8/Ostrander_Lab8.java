package ostrander.ostrander_lab8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 *
 * @author ostra
 */
public class Ostrander_Lab8 {

    public static void main(String[] args) 
    {
        System.out.println("Creating three ArrayLists containing integers, doubles, "
                + "and floats respectively:");
        
        ArrayList<Integer> intList = new ArrayList<>(Arrays.asList(20,15,4,6,86,45));
        ArrayList<Double> doubleList = new ArrayList<>(Arrays.asList(45.2, 12.9, 7.7, 3.0, 16.2, 20.1));
        ArrayList<Float> floatList = new ArrayList<>(Arrays.asList(0.2f, 0.8f, 1.5f, 3.1f, 2.1f, 0.7f));

        
        System.out.println("Each ArrayList has been created with 6 values: ");
        System.out.println("intList values: 20, 15, 4, 6, 86, 45");
        System.out.println("doubleList values: 45.2, 12.9, 7.7, 3.0, 16.2, 20.1");
        System.out.println("floatList values: 0.2, 0.8, 1.5, 3.1, 2.1, 0.7");
        
        //Integer stream
        
        Optional<Integer> maxInt = intList.stream().max(Integer::compareTo);
        Optional<Integer> minInt = intList.stream().min(Integer::compareTo);
        int sumInt = intList.stream().reduce(0, (Integer a, Integer b) -> a + b);
        double avgInt = (double) sumInt / (double) ( intList.stream().count() );
        
        System.out.println("\nTesting the integer stream with functions: ");
        System.out.println("Maximum value: " + maxInt.get() + 
                           "\nMinimum value: " + minInt.get());
        System.out.printf("Average value: %.2f \nTotal value: " + sumInt, 
                                avgInt);
        

        //Double stream
        
        Optional<Double> maxDbl = doubleList.stream().max(Double::compareTo);
        Optional<Double> minDbl = doubleList.stream().min(Double::compareTo);
        double sumDbl = doubleList.stream().reduce(0.0, (Double a, Double b) -> a + b);
        double avgDbl = sumDbl / ( doubleList.stream().count() );
        
        
        System.out.println("\n\nTesting the double stream with functions: ");
        System.out.println("Maximum value: " + maxDbl.get() + 
                           "\nMinimum value: " + minDbl.get());
        System.out.printf("Average value: %.2f \nTotal value: %.2f", 
                                avgDbl, sumDbl);
        
        

        //Forced to convert floats to double - float stream not supported
//        DoubleStream floatStream = IntStream.range(0, floatList.size() )
//                .mapToDouble(i -> floatList.get(i));
        
        OptionalDouble maxFloat = IntStream.range(0, floatList.size() )
                .mapToDouble(i -> floatList.get(i)).max();
        OptionalDouble minFloat = IntStream.range(0, floatList.size() )
                .mapToDouble(i -> floatList.get(i)).min();
        double sumFloat = IntStream.range(0, floatList.size() )
                .mapToDouble(i -> floatList.get(i)).sum();
        OptionalDouble avgFloat = IntStream.range(0, floatList.size() )
                .mapToDouble(i -> floatList.get(i)).average();

  
        System.out.println("\n\nTesting the float stream functions: ");
        System.out.printf("Maximum value: %.2f \n", maxFloat.getAsDouble());
        System.out.printf("Minimum value: %.2f \n", minFloat.getAsDouble());
        System.out.printf("Average value: %.2f \nTotal value: %.2f", 
                                avgFloat.getAsDouble(), sumFloat);

        
        
    }
}
