package ostrander.ostrander_lab9;

/*
 *  ==============================================================
 *  ProducerConsumer.java : Instantiates CubbyHole, Producer and 
 *  Consumer classes and starts Producer and Consumer threads.
 *
 *  Adapted from : Campione M., Walrath K., Huml A., The Java Tutorial, 2000
 *  Modified by : Vasilios Lagakos                     March, 2001
 *  Modified by : Megan Ostrander                      October, 2022
 *  ==============================================================
 */

public class Ostrander_Lab9 {

    public static void main(String[] args) 
    {
        CubbyHole c = new CubbyHole();
        Producer p1 = new Producer(c, 1, 0);
        Consumer c1 = new Consumer(c, 1, 3);
        Consumer c2 = new Consumer(c, 2, 5);

        p1.start();
        c1.start();
        c2.start();
    }
}
