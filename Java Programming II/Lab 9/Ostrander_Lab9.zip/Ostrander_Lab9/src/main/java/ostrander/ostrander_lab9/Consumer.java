package ostrander.ostrander_lab9;

/*
 *  ========================================================================
 *  Consumer.java : A suclass of Thread that consumes and prints all numbers 
 *  from the cubbyhole object as soon as the Producer stores a ID into the 
 *  same cubbyhole object. 
 *
 *  Adapted from : Campione M., Walrath K., Huml A., The Java Tutorial, 2000
 *  Modified by : Vasilios Lagakos                     		March, 2001
 *  =========================================================================
 */

public class Consumer extends Thread {
    private CubbyHole cubbyhole; 	// shared data
    private int ID;                 // ID number for Consumer
    private int valueAssigned;

    public Consumer(CubbyHole c, int number, int number2) {
        cubbyhole = c;
        this.ID = number;
        valueAssigned = number2;
    }

    public void run() 
    {
        int cubbyValue;

//        for (int i = 0; i < 10; i++) 
//        {
//
//            cubbyValue = cubbyhole.get(valueAssigned); 	// Accesses shared data
//            System.out.println("Consumer #" + this.ID
//                           + " got: " + cubbyValue);
//            
//        }
        
        
        // Actually functioning as intended!!
        for (int i = 0; i < 10; i++) 
        {
            cubbyValue = cubbyhole.get(valueAssigned); 	// Accesses shared data
                 
            if(cubbyValue == 99)
            {
                i = 15;                                 //terminate the loop
            }
            else if(cubbyValue != -1)
            {
                System.out.println("Consumer #" + this.ID
                           + " got: " + cubbyValue);
            }
            
        }

    }
    
    
}
