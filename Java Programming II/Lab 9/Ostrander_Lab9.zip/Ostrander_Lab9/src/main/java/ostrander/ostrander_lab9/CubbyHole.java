package ostrander.ostrander_lab9;

/*
 *  ========================================================================
 *  CubbyHole.java : Contains the shared contents which is stored by the Producer
 *  object and consumed by the Consumer object. In order to allow the Consumer
 *  object to consume the contents only once as soon as the Producer object
 *  stores the contents, the synchronized keyword is placed in the put and get methods.
 *  
 *  Adapted from : Campione M., Walrath K., Huml A., The Java Tutorial, 2000
 *  Modified by : Vasilios Lagakos                              March, 2001 
 *  =========================================================================
 */

public class CubbyHole 
{
    private int contents;		// shared data
    private boolean available = false;
    private int attempt = 0;
    private int round = 1;  //Just for organizing attempts to get value

/* Method used by the consumer to access the shared data */
//    public synchronized int get() {	
//        while (available == false) {
//            try {
//                wait();		// Consumer enters a wait state until notified by the Producer
//            } catch (InterruptedException e) { }
//        }
//        available = false;
//        notifyAll();		// Wakes up all threads
//        return contents;	
//    }
    
    
    
    /* Method used by the consumer to access the shared data */
    public synchronized int get(int allowed) {	
        while (available == false) {
            try {
                wait();		// Consumer enters a wait state until notified by the Producer
            } catch (InterruptedException e) { }
        }
        
        
        /*Check that cubbyhole value is divisible by allowed value
          If not, make thread wait.
          If all consumer threads are waiting, notifyAll() and continue process with Producer.
        */
        
        if(contents == 99)
        {
            return contents;
        }
        
        else if(contents % allowed != 0)
        {
            attempt++;
            
            if(attempt > 1)
            {
                //Skip to Producer putting in next value.
                attempt = 0;
                available = false;
                notifyAll();		// Wakes up all threads
            }
            else
            {
                try {
                    wait();		// Consumer enters a wait state until notified by the Producer
                } catch (InterruptedException e) { }
            }

            return -1;
        }
        else
        {
            // Proceed with consumer taking the value from cubby
            attempt = 0;                // Reset attempts.
            available = false;
            notifyAll();		// Wakes up all threads
            return contents;
        }

    }
    
    


/* Method used by the consumer to access (store) the shared data */
    public synchronized void put(int value) {
        while (available == true) {
            try {
                wait();		// Producer who wants to store contents enters 
				// a wait state until notified by the Consumer 
            } catch (InterruptedException e) { }
        }
        
        System.out.println("\nAttempt #" + round);
        round++;
        contents = value;
        available = true;
        notifyAll();		// Producer notifies Consumer to come out 
				// of the wait state and consume the contents
    }
}
