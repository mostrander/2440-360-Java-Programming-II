package com.mycompany.ostrander_lab1_monthapplication;

/**
 *
 * @author ostra
 */
public class Ostrander_Lab1_MonthApplication {

    public static void main(String[] args) 
    {
        System.out.println("Welcome to the Month application test!");
        
        //Create 4 different Month objects for testing
        System.out.println("Creating Amy...");
        Month Amy = new Month(4);
        
        System.out.println("Creating Fred...");
        Month Fred = new Month("February");
        
        System.out.println("Creating Default Joe");
        Month DefaultJoe = new Month();
        
        System.out.println("Creating Anna...");
        Month Anna = new Month("April");
        
        //Output current information...
        //Tests getMonthName and getMonthNumber methods
        System.out.println("Here is the information for each: \n"
                + "Amy was born in: " + Amy.getMonthName() + " (" + Amy.getMonthNumber() + ")\n"
                + "Fred was born in: " + Fred.getMonthName() + " (" + Fred.getMonthNumber() + ")\n"
                + "Default Joe was born in: " + DefaultJoe.getMonthName() + " (" + DefaultJoe.getMonthNumber() + ")\n"
                + "Anna was born in: " + Anna.getMonthName() + " (" + Anna.getMonthNumber() + ")\n");
        
        //Test greaterThan method
        System.out.println("Is Default Joe's birthday after Amy's? " + DefaultJoe.greaterThan(Amy));
        System.out.println("Is Amy's birthday after Fred's? " + Amy.greaterThan(Fred) + "\n");
        
        //Test lessThan method
        System.out.println("Is Default Joe's birthday before Fred's? " + DefaultJoe.lessThan(Fred));
        System.out.println("Is Anna's birthday before Amy's? " + Anna.lessThan(Amy) + "\n");
        
        //Test equals method
        System.out.println("Are Amy and Anna born in the same month? " + Amy.equals(Anna));
        System.out.println("Are Deafult Joe and Fred born in the same month? " + DefaultJoe.equals(Fred) + "\n");
        
        //Test that constructor that takes number sets it properly
        System.out.println("Creating Betty...");
        Month Betty = new Month(54);
        
        System.out.println("Betty was born in: " + Betty.toString() + " (" + Betty.getMonthNumber() + ")");
        
    }
}
