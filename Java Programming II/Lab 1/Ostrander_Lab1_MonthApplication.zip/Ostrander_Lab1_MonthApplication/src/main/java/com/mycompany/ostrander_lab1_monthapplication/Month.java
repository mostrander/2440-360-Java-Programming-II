package com.mycompany.ostrander_lab1_monthapplication;

/**
 *
 * @author ostra
 */
public class Month {
    
    private int monthNumber;
    private String monthName;
    
    //Constructors for the Class.
    public Month ()
    {
        monthNumber = 1;
        String defaultNum = String.valueOf(monthNumber);
        setMonthName(defaultNum);
    }
    
    public Month (int numberGiven)
    {
        setMonthNumber(numberGiven);
    }
    
    public Month (String nameGiven)
    {
        setMonthName(nameGiven);
    }
    
    //Method determines what month to set based on number given
    //If invalid number is given, default to 1
    //Anything other than 1 calls setMonthName method.
    private void setMonthNumber(int numberGiven)
    {
        if(numberGiven < 1 || numberGiven > 12)
        {
            monthNumber = 1;
            monthName = "January";
        }
        else
        {
            monthNumber = numberGiven;
            String given = String.valueOf(numberGiven);
            setMonthName(given);
        }
    }
    
    private void setMonthName(String given)
    {
        switch (given)
        {
            case "January":
            case "1":
                monthName = "January";
                monthNumber = 1;
                break;
            case "February":
            case "2":
                monthName = "February";
                monthNumber = 2;
                break;
            case "March":
            case "3":
                monthName = "March";
                monthNumber = 3;
                break;
            case "April":
            case "4":
                monthName = "April";
                monthNumber = 4;
                break;
            case "May":
            case "5":
                monthName = "May";
                monthNumber = 5;
                break;
            case "June":
            case "6":
                monthName = "June";
                monthNumber = 6;
                break;
            case "July":
            case "7":
                monthName = "July";
                monthNumber = 7;
                break;
            case "August":
            case "8":
                monthName = "August";
                monthNumber = 8;
                break;
            case "September":
            case "9":
                monthName = "September";
                monthNumber = 9;
                break;
            case "October":
            case "10":
                monthName = "October";
                monthNumber = 10;
                break;
            case "November":
            case "11":
                monthName = "November";
                monthNumber = 11;
                break;
            case "December":
            case "12":
                monthName = "December";
                monthNumber = 12;
                break;
            default:
                System.out.println("The name given does not match any known"
                        + " months. Please try again.");
                break;
        }
    }
    
    public int getMonthNumber()
    {
        return monthNumber;
    }
    
    public String getMonthName()
    {
        return monthName;
    }
    
    //If the information in both objects match, return true.
    public Boolean equals(Month object1)
    {
        if( (object1.getMonthNumber() == getMonthNumber()) &&
                object1.getMonthName() == getMonthName())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    //If the calling object's monthNumber is greater, return true
    public Boolean greaterThan(Month object1)
    {
        if(getMonthNumber() > object1.getMonthNumber())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    //If the calling object's monthNumber is less, return true
    public Boolean lessThan(Month object1)
    {
        if(getMonthNumber() < object1.getMonthNumber())
        {
            return true;
        }
        else{
            return false;
        }
    }
    
    @Override
    public String toString()
    {
        return monthName;
    }
}
