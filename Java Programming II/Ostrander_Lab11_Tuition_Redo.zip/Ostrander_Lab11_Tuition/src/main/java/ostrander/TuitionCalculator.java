package ostrander;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ostra
 */
public class TuitionCalculator implements java.io.Serializable
{
    private int creditHours;
    private int resCode; //Residency code or zip code given
    private double creditPrice; //number of credit hours
    private final ArrayList<Integer> county; //stores list of in-county zipcodes

    public TuitionCalculator()
    { 
        //List of in county zip codes
       county = new ArrayList<>();
       county.add(44011);
       county.add(44012);
       county.add(44028);
       county.add(44035);
       county.add(44036);
       county.add(44039);
       county.add(44044);
       county.add(44049);
       county.add(44050);
       county.add(44052);
       county.add(44053);
       county.add(44054);
       county.add(44055);
       county.add(44074);
       county.add(44090);
    }
    
    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    public int getResCode() 
    {
        return resCode;
    }

    public void setResCode(int resCode) 
    {
        this.resCode = resCode;
               
    }


    //read-only property
    public double getTuition() 
    {
        if( !(creditHours < 13) & !(creditHours > 18) )
        {
            //13 - 18 credit hours uses the same tuition price.
            return creditPrice * 13;
        }
        else if(creditHours > 18)
        {
            //Add additional cost of hours to the price locked amount
            int difference = creditHours - 18;
            return (creditPrice * 13) + (difference * creditPrice);
        }
        else
        {
            return creditPrice * creditHours;  
        }
    }


    //Read-only property
    public double getCreditPrice() 
    {
        
        if (county.contains(resCode))
        {
            //zip code is in Lorain county, apply lorain county rates
            creditPrice = 154.03;
        }
        else if (resCode >= 43001 & resCode <= 45999)
        {
            //zip code is in Ohio, apply Ohio rates
            creditPrice = 179.21;
        }
        else
        {
            //zip code given is not in Ohio. Apply out of state rates
            creditPrice = 330.78;
        }
        
        return creditPrice;
    }
    
    
}
