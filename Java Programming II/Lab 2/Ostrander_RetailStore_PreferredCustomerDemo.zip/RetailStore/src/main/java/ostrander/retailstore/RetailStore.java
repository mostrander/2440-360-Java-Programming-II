/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ostrander.retailstore;

import java.util.Scanner;

/**
 *
 * @author Megan Ostrander
 */
public class RetailStore {

    public static void main(String[] args) 
    {
        //Demonstrating Customer Class.
        System.out.println("This is a demo of the Customer class.\n");
        System.out.println("Creating an object of the PreferredCustomer class with the default "
                + "constructor and the following information provided: \n"
                + "Name, address, phone number, and mail permission.\n");
        
        System.out.println("Note: This demo does not cover the methods for changing the customer's "
                + "information, nor the validation methods concerning name, address, and phone number "
                + "input. \nThose were covered in the Customer class demo.\n");
        
        //Create Customer object
        PreferredCustomer example = new PreferredCustomer("Anna Logan", "123 Fairytale Lane", "123 456 7890", false);
        
        //Output the starting information.
        System.out.println("Printing the customer's information using the printInfo() method.");
        example.printInfo();
        System.out.println("\nNote: Mail permission is required for the PreferredCustomer class.");
        
        
        //Show updateTotalSpent() method
        System.out.println("Now, I will show the customer's total spent information updated "
                + "using the updateTotalSpent() method.\n"
                + "I will use the totalSpentToDate() method to display amount spent, "
                + "and the hasDiscount() method to determine customer's discount level.\n"
                + "Discount levels increase every $500 until level 4 ($2000).\n");
        
        System.out.println("Total: " + example.totalSpentToDate());
        System.out.println("Adding 150.36");
        example.updateTotalSpent(150.36);
        System.out.println("Total: $" + example.totalSpentToDate());
        System.out.println("Discount level: " + example.hasDiscount() + "\n");
        
        System.out.println("Total: " + example.totalSpentToDate());
        System.out.println("Adding 601.75");
        example.updateTotalSpent(601.75);
        System.out.println("Total: $" + example.totalSpentToDate());
        System.out.println("Discount level: " + example.hasDiscount() + "\n");
        
        System.out.println("\nTotal: " + example.totalSpentToDate());
        System.out.println("Adding 249.00");
        example.updateTotalSpent(249.00);
        System.out.println("Total: $" + example.totalSpentToDate());
        System.out.println("Discount level: " + example.hasDiscount());
        
        System.out.println("\nTotal: " + example.totalSpentToDate());
        System.out.println("Adding 500.01");
        example.updateTotalSpent(500.01);
        System.out.println("Total: $" + example.totalSpentToDate());
        System.out.println("Discount level: " + example.hasDiscount());
        
        System.out.println("\nTotal: " + example.totalSpentToDate());
        System.out.println("Adding 500.08");
        example.updateTotalSpent(500.08);
        System.out.println("Total: $" + example.totalSpentToDate());
        System.out.println("Discount level: " + example.hasDiscount());
        
        System.out.println("\nAs shown in the last example, the total spent should be "
                + "formatted to display only 2 decimal places when displayed.");
        System.out.printf("Total (formatted): $%.2f", example.totalSpentToDate());
        
        System.out.println("\nNote: The discount level is automatically updated by the "
                + "updateDiscountLevel() method in the PreferredCustomer class.\n"
                + "The method is called when using the updateTotalSpent() method.\n");
        
        
        //Show the constructor for when entering a total spent
        System.out.println("Now creating another customer with the total spent specified ($699.99).");
        PreferredCustomer example2 = new PreferredCustomer("Luna Frey", "123 Dreamland Dr.", "123-456-7899", false, 699.99);
        
        //Print information.
        System.out.println("Here is the new customer's information: ");
        example2.printInfo();
        
        
        //Demonstrated the validation methods pertaining to PreferredCustomer class.
        System.out.println("\nThe following is a demonstration of validation methods for the"
                + "PreferredCustomer class input.\n"
                + "Note: Print statements are included in the method for testing purposes.\n");
        
        System.out.println("First will be the validTransactionAmt() method.\n"
                + "It verifies that the input is a valid number.\n");
        
        System.out.println("Testing a blank entry.");
        validTransactionAmt("");
        
        System.out.println("\nTesting and entry with only spaces. ");
        validTransactionAmt("   ");
        
        System.out.println("\nTesting the entry: abcd");
        validTransactionAmt("abcd");
        
        System.out.println("\nTesting the entry: 24KB");
        validTransactionAmt("24KB");
        
        System.out.println("\nTesting the entry: 36");
        validTransactionAmt("36");
        
        System.out.println("\nTesting the entry: 84.36");
        validTransactionAmt("84.36");
        
        System.out.println("\nTesting the entry: -74.99");
        validTransactionAmt("-74.99");
        
        
        //Now, demo the applyDiscount() method
        System.out.println("\nNow, a demonstration of the applyDiscount() method.\n"
                + "The method takes the transaction amount and the customer's discount level.\n");
        
        double discountApplied = 0.0; //used for testing
        double finalCost = 0.0;
        
        System.out.println("Using the following information: $34.66, level 0.");
        discountApplied = applyDiscount(34.66, 0);
        finalCost = 34.66 - discountApplied;
        
        System.out.printf("Discount for this transaction: $%.2f\n"
                + "Final Cost: $%.2f", discountApplied, finalCost);
        
        
        System.out.println("\n\nUsing the following information: $699.99, level 1.");
        discountApplied = applyDiscount(699.99, 1);
        finalCost = 699.99 - discountApplied;
        
        System.out.printf("Discount for this transaction: $%.2f\n"
                + "Final Cost: $%.2f", discountApplied, finalCost);
        
        
        System.out.println("\n\nUsing the following information: $250.75, level 2.");
        discountApplied = applyDiscount(250.75, 2);
        finalCost = 250.75 - discountApplied;
        
        System.out.printf("Discount for this transaction: $%.2f\n"
                + "Final Cost: $%.2f", discountApplied, finalCost);
        
        
        System.out.println("\n\nUsing the following information: $950.00, level 3.");
        discountApplied = applyDiscount(950.00, 3);
        finalCost = 950.00 - discountApplied;
        
        System.out.printf("Discount for this transaction: $%.2f\n"
                + "Final Cost: $%.2f", discountApplied, finalCost);
        
        
        System.out.println("\n\nUsing the following information: $1699.99, level 4.");
        discountApplied = applyDiscount(1699.99, 4);
        finalCost = 1699.99 - discountApplied;
        
        System.out.printf("Discount for this transaction: $%.2f\n"
                + "Final Cost: $%.2f", discountApplied, finalCost);
        
        
        //Now test using a PreferredCustomer object.
        System.out.println("\n\nHere is an example using a PreferredCustomer class object:\n"
                + "Starting information:\n");
        
        example2.printInfo();
        
        System.out.println("\nNow, let us add $595.36 as a transaction: ");
        discountApplied = applyDiscount(595.36, example2.hasDiscount());
        finalCost = 595.36 - discountApplied;
        
        System.out.printf("Discount for this transaction: $%.2f\n"
                + "Final Cost: $%.2f", discountApplied, finalCost);
        
        example2.updateTotalSpent(finalCost);
        
        System.out.println("\n\nUpdated account information:\n");
        example2.printInfo();
        
        
        
        
    }
    

    
    //Need input verification methods
    private static boolean validNameInput(String input)
    {
        if (input.isBlank()) 
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(!input.matches("^[ .A-Za-z]+$"))
        {
            System.out.println("Error: Entry should only contain letters, periods, and spaces.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    private static boolean validAddressInput(String input)
    {
        if (input.isBlank()) 
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(input.length() <= 4)
        {
            System.out.println("Error: Input too short. Need more information.");
            return false;
        }
        else if(!input.matches("^[ .,0-9A-Za-z]+$"))
        {
            System.out.println("Error: Entry should only contain letters, numbers, periods, commas, and spaces.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    private static boolean validPhoneNumber(String input)
    {
        if(input.isBlank())
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(input.length() < 7) //international phone number min length is 7
        {
            System.out.println("Phone number given does not meet minimum length requirements (7 digits).");
            return false;
        }
        else if(!input.matches("^[ -.0-9]+$"))
        {
            System.out.println("Error: Phone number should only contain numbers 0 - 9, periods, spaces, and dashes.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    
    //Methods concerning PreferredCustomer Class.
    private static boolean validTransactionAmt(String input)
    {
        if(input.isBlank())
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(!input.matches("^[ -.0-9]+$"))
        {
            System.out.println("Error: Input should only contain numbers 0 - 9 and a dash symbol for negative numbers.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    
    private static double applyDiscount(double purchase,int level)
    {
        double discountRate;
        
        discountRate = switch (level) {
            case 1 -> 0.05;
            case 2 -> 0.06;
            case 3 -> 0.07;
            case 4 -> 0.10;
            default -> 0.00;
        };
        
        //Multiply the purchase price by discountRate rate to determine discountRate
        return discountRate * purchase;
    }
}
