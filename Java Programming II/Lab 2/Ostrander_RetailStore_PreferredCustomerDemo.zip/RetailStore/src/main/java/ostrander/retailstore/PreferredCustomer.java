package ostrander.retailstore;


public class PreferredCustomer extends Customer 
{
    private double totalSpent; //Amount of money customer has spent, cumulative
    private int discountLevel; //Determines percentage of discount on all future purchases
    
    //Default constructor for new customers - nothing spent/purchased
    public PreferredCustomer(String nameGiven, String addressGiven, String phoneGiven, 
            boolean mailPermission)
    {
        //Obtain information required for Person & Customer classes
        super(nameGiven, addressGiven, phoneGiven, mailPermission);
        
        totalSpent = 0.0;
        discountLevel = 0;
    }
    
    //Constructor for users whom have spent money already
    //i.e., joined at checkout, need re-entered into system, etc.
    public PreferredCustomer(String nameGiven, String addressGiven, String phoneGiven, 
            boolean mailPermission, double purchaseAmt)
    {
        //Obtain information required for Person & Customer classes
        super(nameGiven, addressGiven, phoneGiven, mailPermission);
        
        totalSpent = purchaseAmt;
        updateDiscountLevel();
    }
    
    //Method for calculating discount level based on totalSpent
    private void updateDiscountLevel()
    {
        if(totalSpent >= 2000.0)
        {
            discountLevel = 4;
            //System.out.println("Congradulations! You qualify for a 10% discount!");
        }
        else if(totalSpent >= 1500.0)
        {
            discountLevel = 3;
            //System.out.println("Congradulations! You qualify for a 7% discount!");
        }
        else if (totalSpent >= 1000.0)
        {
            discountLevel = 2;
            //System.out.println("Congradulations! You qualify for a 6% discount!");
        }
        else if(totalSpent >= 500.0)
        {
            discountLevel = 1;
            //System.out.println("Congradulations! You qualify for a 5% discount!");
        }
        else
        {
            //System.out.println("You do not qualify for a discount at this time.");
        }
    }
    
    //Adds new purchases to the amount spent for account, updates discount level
    public void updateTotalSpent(double amt)
    {
        totalSpent += amt;
        updateDiscountLevel();
    }
    
    //Returns discount level for individual
    public int hasDiscount()
    {
        return discountLevel;
    }
    
    public double totalSpentToDate()
    {
        return totalSpent;
    }
    
    @Override
    public void printInfo()
    {
                System.out.printf("Customer Name: " + name + "\nAddress: " + address 
                + "\nPhone Number: " + phoneNum
                + "\nCustomer ID: " + customerID 
                + "\nMail Permission: " + mailList
                + "\nTotal Amount Spent: $%.2f\n"
                + "Discount Level: " + discountLevel + "\n", totalSpent);
    }
    
}
