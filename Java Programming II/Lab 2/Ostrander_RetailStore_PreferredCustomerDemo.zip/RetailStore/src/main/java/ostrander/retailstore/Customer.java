package ostrander.retailstore;
import java.util.Random;


public class Customer extends Person 
{
    final int customerID; //Holds customer number, should not be altered
    boolean mailList; //True = mail info, false = do not mail info
    private final int customerUpperLimit = 2000; //Forces random ID numbers to be POSITIVE
    
    //Constructor that accepts the only required information
    public Customer(String nameGiven, String addressGiven, String phoneGiven)
    {
        super(nameGiven, addressGiven, phoneGiven);
        Random idGenerator = new Random();
        
        customerID = idGenerator.nextInt(customerUpperLimit) +1; //Assign random ID number
        mailList = true; //default 
    }
    
    //Constructor that takes all provided information
    public Customer(String nameGiven, String addressGiven, String phoneGiven, boolean mailPermission)
    {
        super(nameGiven, addressGiven, phoneGiven);
        Random idGenerator = new Random();
        
        customerID = idGenerator.nextInt(customerUpperLimit) +1; //Assign random ID number
        mailList = mailPermission;
    }
    
    //Retrieves customer ID number
    public int getCustomerID()
    {
        return customerID;
    }
    
    //Retrieve mail permission information
    public boolean hasMailPermission()
    {
        return mailList;
    }
    
    //Modify mailList permissions
    public void updateMailingPermissions(boolean permission)
    {
        mailList = permission;
    }
    
    @Override
    public void printInfo()
    {
        System.out.println("Customer Name: " + name + "\nAddress: " + address 
                + "\nPhone Number: " + phoneNum
                + "\nCustomer ID: " + customerID 
                + "\nMail permission: " + mailList);
    }
    
}
