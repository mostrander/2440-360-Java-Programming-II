/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ostrander.retailstore;

import java.util.Scanner;

/**
 *
 * @author Megan Ostrander
 */
public class RetailStore {

    public static void main(String[] args) 
    {
        //Demonstrating Customer Class.
        System.out.println("This is a demo of the Customer class.\n");
        System.out.println("Creating an object of the Customer class with the default "
                + "constructor and the following information provided: \n"
                + "Name, address, and phone number.\n");
        
        //Create Customer object
        Customer example = new Customer("Anna Logan", "123 Fairytale Lane", "9999999999");
        
        //Output information using get methods.
        System.out.println("Information for the object will now be output to the "
                + "screen using the following methods: \n"
                + "getName(), getAddress(), getPhone(), getCustomerID().");
        
        System.out.println("\nCustomer Name: " + example.getName()
                + "\nAddress: " + example.getAddress()
                + "\nPhone Number: " + example.getPhone()
                + "\nCustomer ID: " + example.getCustomerID());
        
        
        //Change name of the Customer.
        System.out.println("\nNow, I will change the name associated with the object "
                + "using the updateName() method.\n");
        
        System.out.println("Name before change: " + example.getName());
        example.updateName("Pudding");
        System.out.println("Name after change: " + example.getName() + "\n");
        
        
        //Change address information of Customer
        System.out.println("\nNow, I will change the address associated with the object "
                + "using the updateAddress() method.\n");
        
        System.out.println("Address before change: " + example.getAddress());
        example.updateAddress("666 Nightmare Drive");
        System.out.println("Address after change: " + example.getAddress() + "\n");
        
        
        //Update phone information of Customer
        System.out.println("Now, I will change the phone number associated with the object "
                + "using the updatePhone() method.\n");
        
        System.out.println("Phone number before change: " + example.getPhone());
        example.updatePhone("123 456 7890");
        System.out.println("Phone number after change: " + example.getPhone() + "\n");
        
        
        //Output information regarding mailing permissions
        System.out.println("Outputting information regarding whether the customer permits mail advertisements.\n"
                + "It should be set to true due to using default constructor.\n"
                + "Using hasMailPermission() method to obtain the information.\n");
        
        System.out.println("Does the customer permit mail advertisements? " + example.hasMailPermission());
        
        System.out.println("\nChanging the permission to false using the updateMailingPermissions() method.");
        example.updateMailingPermissions(false);
        System.out.println("Does the customer permit mail advertisements? " + example.hasMailPermission());
        
        
        //Display all information using the printInfo() method
        System.out.println("\nPrinting all customer information using the printInfo() method: \n");
        example.printInfo();
        
        
        //Create another object with mail permission info given
        System.out.println("\nCreating another customer object with mail permissions specified as false.");
        Customer example2 = new Customer("Sasha May", "7584 West Tester Lane", "695 695 6959", false);
        
        System.out.println("\nPrinting the information for the new customer.");
        example2.printInfo();
        
        
        //Showcase the validation methods listed beneath main class
        System.out.println("\n\nI will now show the validNameInput() method for verifying "
                + "a name given to the program. Method contains print statements for testing.\n");
        
        System.out.println("Testing an empty string (nothing entered).");
        validNameInput("");
        
        System.out.println("\nTesting an empty string (only spaces entered).");
        validNameInput("    ");
        
        System.out.println("\nTesting a string of numbers: 1236");
        validNameInput("1236");
        
        System.out.println("\nTesting a string of letters and numbers: De26f zdg 681");
        validNameInput("De26f zdg 681");
        
        System.out.println("\nTesting the string: Mary Cross");
        validNameInput("Mary Cross");
        
        System.out.println("\nTesting the string: Monkey D. Luffy");
        validNameInput("Monkey D. Luffy");
        
        
        
        //Showcase the validation methods listed beneath main class
        System.out.println("\n\nI will now show the validAddressInput() method for verifying "
                + "an address given to the program. Method contains print statements for testing.\n");
        
        System.out.println("Testing an empty string (nothing entered).");
        validAddressInput("");
        
        System.out.println("\nTesting an empty string (only spaces entered).");
        validAddressInput("    ");
        
        System.out.println("\nTesting a string of numbers: 1236");
        validAddressInput("1236");
        
        System.out.println("\nTesting a string of letters and numbers: De26f zdg 681");
        validAddressInput("De26f zdg 681");
        
        System.out.println("\nTesting the string: 142-6 East Wainstead Dr.");
        validAddressInput("Mary Cross");
        
        System.out.println("\nTesting the string: 1426 East Wainstead Dr.");
        validAddressInput("1426 East Wainstead Dr.");
        
        System.out.println("\nTesting the string: 12 South Looney Lane, Parma, Ohio");
        validAddressInput("12 South Looney Lane, Parma, Ohio");
        
        
        
        //Showcase the validation methods listed beneath main class
        System.out.println("\n\nI will now show the validPhoneNumber() method for verifying "
                + "a phone number given to the program. Method contains print statements for testing.\n");
        
        System.out.println("Testing an empty string (nothing entered).");
        validPhoneNumber("");
        
        System.out.println("\nTesting an empty string (only spaces entered).");
        validPhoneNumber("                          ");
        
        System.out.println("\nTesting a string of numbers: 1236");
        validPhoneNumber("1236");
        
        System.out.println("\nTesting a string of letters and numbers: De26f zdg 681");
        validPhoneNumber("De26f zdg 681");
        
        System.out.println("\nTesting the string: 1234567890");
        validPhoneNumber("1234567890");
        
        System.out.println("\nTesting the string: 123 456 7890");
        validPhoneNumber("123 456 7890");
        
        System.out.println("\nTesting the string: 123-456-7890");
        validPhoneNumber("123.456.7890");
        
        System.out.println("\nTesting the string: 123,456,7890");
        validPhoneNumber("123,456,7890");
        
        
        
        
        
        
        
    }
    

    
    //Need input verification methods
    private static boolean validNameInput(String input)
    {
        if (input.isBlank()) 
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(!input.matches("^[ .A-Za-z]+$"))
        {
            System.out.println("Error: Entry should only contain letters, periods, and spaces.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    private static boolean validAddressInput(String input)
    {
        if (input.isBlank()) 
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(input.length() <= 4)
        {
            System.out.println("Error: Input too short. Need more information.");
            return false;
        }
        else if(!input.matches("^[ .,0-9A-Za-z]+$"))
        {
            System.out.println("Error: Entry should only contain letters, numbers, periods, commas, and spaces.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    private static boolean validPhoneNumber(String input)
    {
        if(input.isBlank())
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(input.length() < 7) //international phone number min length is 7
        {
            System.out.println("Phone number given does not meet minimum length requirements (7 digits).");
            return false;
        }
        else if(!input.matches("^[ -.0-9]+$"))
        {
            System.out.println("Error: Phone number should only contain numbers 0 - 9, periods, spaces, and dashes.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    
    //Methods concerning PreferredCustomer Class.
    private static boolean validTransactionAmt(String input)
    {
        if(input.isBlank())
        {
            System.out.println("Error: Nothing was entered.");
            return false;
        }
        else if(!input.matches("^[ .0-9]+$"))
        {
            System.out.println("Error: Phone number should only contain numbers 0 - 9.");
            return false;
        }
        else
        {
            System.out.println("Success.");
            return true;
        }
    }
    
    
    private static double applyDiscount(double purchase,int level)
    {
        double discountRate;
        
        discountRate = switch (level) {
            case 1 -> 0.05;
            case 2 -> 0.06;
            case 3 -> 0.07;
            case 4 -> 0.10;
            default -> 0.00;
        };
        
        //Multiply the purchase price by discountRate rate to determine discountRate
        return discountRate * purchase;
    }
}
