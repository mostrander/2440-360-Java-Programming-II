package ostrander.retailstore;


public class Person 
{
    //All three are required for simplicity
    String name;
    String address;
    String phoneNum; 
    
    //Constructor for when all information is provided.
    public Person (String nameGiven, String addressGiven, String phoneGiven)
    {
        name = nameGiven;
        address = addressGiven;
        phoneNum = phoneGiven;
    }   
    
    //Method for retrieving name of individual
    public String getName()
    {
        return name;
    }
    
    //Method for retrieving address of individual
    public String getAddress()
    {
        return address;
    }
    
    //Method for retrieving phone number (if available)
    public String getPhone()
    {
        return phoneNum;
    }
    
    //Method prints all information
    public void printInfo()
    {
        System.out.println(name + ", " + address + ", " + phoneNum);
    }
    
    //Method updates the individual's name (in case of mistakes or marriage, etc.)
    public void updateName(String nameGiven)
    {
        name = nameGiven;
    }
    
    //Method updates address information
    public void updateAddress(String addressGiven)
    {
        address = addressGiven;
    }
    
    //Method updates phone number information
    public void updatePhone(String phoneGiven)
    {
        phoneNum = phoneGiven;
    }
    
}
