/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package ostrander.ostrander_lab3_golfer;

/**
 *
 * @author ostra
 */
public class Golfer_Exception extends Exception {

    /**
     * Creates a new instance of <code>Golfer_Exception</code> without detail
     * message.
     */
    public Golfer_Exception() 
    {
        System.out.println("An unexpected error has occurred with the Golfer program.");
    }

    /**
     * Constructs an instance of <code>Golfer_Exception</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public Golfer_Exception(String msg) 
    {
        super(msg);
    }
}
