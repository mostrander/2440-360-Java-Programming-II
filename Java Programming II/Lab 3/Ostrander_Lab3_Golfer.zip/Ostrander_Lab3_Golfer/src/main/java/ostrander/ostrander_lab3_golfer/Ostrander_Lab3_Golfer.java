/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package ostrander.ostrander_lab3_golfer;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author ostra
 */
public class Ostrander_Lab3_Golfer {

    public static void main(String[] args) throws Golfer_Exception 
    {
        //Demo of Golfer class.
        //Create array variable to hold information
        int[] scoreInput;
        
        try
        {
            System.out.println("This is a demo of the Golfer Class.\n"
                    + "Creating a Golfer object by the name of Joe Bob: ");
            Golfer newGolfer = new Golfer("Joe Bob");

            System.out.println("\nTesting object with incorrect value (numbers): J0e Bob\n"
                    + "Causes an exception. Uncomment to test.");
            //newGolfer = new Golfer("J0e Bob");

            System.out.println("\nTesting object with incorrect value (dashes): Joe-Bob\n"
                    + "Causes an exception. Uncomment to test.");
            //newGolfer = new Golfer("Joe-Bob");

            System.out.println("\nTesting object with incorrect value (special character): Joe Bob!\n"
                    + "Causes an exception. Uncomment to test.");
            //newGolfer = new Golfer("Joe Bob!");

            System.out.println("\nTesting object with incorrect value (blank)\n"
                    + "Causes an exception. Uncomment to test.");
            //newGolfer = new Golfer("");

            System.out.println("\nTesting object with incorrect value (spaces only)\n"
                    + "Causes an exception. Uncomment to test.");
            //newGolfer = new Golfer("        ");



           //Add values to the array
           System.out.println("\nNow testing the saveScores() method.");
           System.out.println("Passing array with no specified elements and size 18.");
           System.out.println("This does NOT produce an error because it initializes a blank array "
                   + "of specified size, all elements automatically set to zero.\n"
                   + "Uncomment to test.");

    //           scoreInput = new int[18];
    //           newGolfer.saveScores(scoreInput);
    //           
    //           System.out.println("Entries in the array passed to the method:");
    //           for(var value:scoreInput)
    //           {
    //               System.out.print(value + ",");
    //           }
    //            

           System.out.println("\nPassing array with specified elements and size 10.");
           System.out.println("Produces an error because array is less than 18 elements (scores).\n"
                   + "Uncomment to test.");

    //           scoreInput = new int[] {1,2,3,4,5,6,7,8,9,10};
    //           newGolfer.saveScores(scoreInput);


           System.out.println("\nPassing array with 0 elements (size 0).");
           System.out.println("Produces an error because array contains no elements (scores).\n"
                   + "Uncomment to test.");

    //           scoreInput = new int[0];
    //           newGolfer.saveScores(scoreInput);


           System.out.println("\nPassing array with specified elements and size 21.");
           System.out.println("Produces an error because array is more than 18 elements (scores).\n"
                   + "Uncomment to test.");

    //           scoreInput = new int[] {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21};
    //           newGolfer.saveScores(scoreInput);


           System.out.println("\nPassing array with specified elements and size 18.");
           System.out.println("This array will be used to test the saveScores() and retrieveScores() methods.");

           scoreInput = new int[] {5,3,4,8,5,2,1,0,2,3,5,1,6,2,5,0,1,3};
           newGolfer.saveScores(scoreInput);

           System.out.println("Entries in the array passed to the method:");
           for(var value:scoreInput)
           {
               System.out.print(value + ",");
           }


           //Call the retrieveScores() method
           System.out.println("\n\nCalling the retrieveScores() method and storing in another array object.");
           int[] retrieveTest = newGolfer.retrieveScores();

           System.out.println("These scores were retrieved from Joe Bob's saved file:");
           for(var value:retrieveTest)
           {
               System.out.print(value + ",");
           }


           //Test of the calcTotalScore() method
           System.out.println("\n\nCalling the totalScore() method to add up Joe Bob's score:");
           System.out.println(newGolfer.calcTotalScore());


           Golfer testGolfer = new Golfer("Logan");
           
            //Example of failure to retrieve a file.
            System.out.println("\n\nTest of failure to retrieve a golfer's score file."
                    + "\nUncomment to test.");
                
//            testGolfer.retrieveScores();

    
            //Example of failure to retrieve a file.
            System.out.println("\n\nTest of failure to calculate a golfer's score file."
                    + "\nUncomment to test.");

//            System.out.println(testGolfer.calcTotalScore());
            

        }
        catch(Exception ex)
        {
            System.err.print(ex);
            System.out.println("\nError encountered. Terminating program.");
            System.exit(0);
        }
        
   
        //End of Main
    }
    
    
    
    
    
    
}
