package ostrander.ostrander_lab3_golfer;

import java.io.*;
import java.util.Scanner;


public class Golfer 
{
    private String name;
    
    public Golfer(String nameGiven) throws Golfer_Exception
    {
        try
        {
            if(nameGiven.isBlank())
            {
                throw new Exception("Nothing was entered.");
            }
            else if(!nameGiven.matches("^[ .A-Za-z]+$"))
            {
                throw new Exception("Input should only contain letters, periods, and spaces.");
            }
            else
            {
                name = nameGiven;
            }
        }
        catch(Exception e)
        {
            throw new Golfer_Exception(e.getMessage()); 
        }
    }
    
    //Saves golfer's scores to a binary file. Takes an int array
    public void saveScores(int[] scoresGiven) throws Golfer_Exception
    {
        try
        {
            //Throw error if array does not contain exactly 18 scores.
            if(scoresGiven.length <= 0 || scoresGiven == null)
            {
                throw new Exception("No scores have been entered.");
            }
            else if(scoresGiven.length >= 19)
            {
                throw new Exception("Too many scores have been entered.");
            }
            else if(scoresGiven.length != 18)
            {
                throw new Exception("Exactly 18 scores was not entered.");
            }
            else
            {
                //Create and open file
                FileOutputStream fstream = new FileOutputStream (name + ".dat");
                DataOutputStream saveFile = new DataOutputStream(fstream);
                
                //PrintWriter saveFile = new PrintWriter(name + ".dat");
                
                //Write to file each score.
                for(var score:scoresGiven)
                {
                    //saveFile.println(score);
                    saveFile.write(score);
                }
                
                saveFile.close(); //close file
            }
        }
        catch(Exception e)
        {
            throw new Golfer_Exception(e.getMessage());
        }
    }
    
    
    //Retrieves and reads goolfer's score file. Returns int array.
    public int [] retrieveScores() throws Golfer_Exception
    {
        int[] scores = new int[18]; //only holds 18 values
        
        try
        {
            String fileName = name + ".dat";
            
            FileInputStream fstream = new FileInputStream(fileName);
            DataInputStream input = new DataInputStream(fstream);
            
            
//            File retrievedFile = new File(fileName);            
//            Scanner input = new Scanner(retrievedFile);

            int count = 0;
            
            while(count < 18)
            {
                scores[count] = input.read();
                
                //scores[count] = input.nextInt();
                //System.out.println("Value entered: " + scores[count]); 
                count++;              
            }
            
        }
        catch(Exception e)
        {
            throw new Golfer_Exception("The file " + name + ".dat does not exist.");
        }
        
        return scores;
    }
    
    
    //method for calculating total score, retrieves and reads file.
    public int calcTotalScore() throws Golfer_Exception
    {
        int total = 0;
        
        try
        {
            String fileName = name + ".dat";
            
            FileInputStream fstream = new FileInputStream(fileName);
            DataInputStream input = new DataInputStream(fstream);
            
            while(true)
            {
                total += input.readByte();
            }

                 
        }
        catch(EOFException e)
        {
            //Expected to produce exception - no other way to determine end of binary file
            return total;
        }
        catch(IOException e)
        {
            throw new Golfer_Exception("The file " + name + ".dat does not exist.");
        }
        
        
    }
    
    
}
