package ostrander.ostrander_lab5_javafx;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * JavaFX App
 */
public class App extends Application {

    //Needed to display information
    private TextField textReadOnly1;
    private TextField textReadOnly2;
    
    //Needed to obtain user input
    private TextField userInput1;
    private ComboBox monthComboBox;
    private ComboBox numComboBox;
    
    Stage window;
    Scene mainProgram;
    Scene helpScreen;
    Scene aboutScreen;
    
    BorderPane layout;
    
    
    @Override
    public void start(Stage stage) {
        window = stage;
        
        textReadOnly1 = new TextField(); //Section 1, readonly display field
        textReadOnly1.setEditable(false); //make read only.
        
        textReadOnly2 = new TextField(); //Section 2, readonly display field
        textReadOnly2.setEditable(false); //make read only.
        
        userInput1 = new TextField(); //Section 1, field for user input
        
        
        //Create list for month options, create combobox using list, for section 2
        ObservableList<String> monthOptions = 
        FXCollections.observableArrayList(
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
        );
        
        monthComboBox = new ComboBox(monthOptions);
        
        
        //Create list containing month numbers, create combobox, for section 2
        ObservableList<String> numberOptions = 
        FXCollections.observableArrayList(
        "1","2","3","4","5","6","7","8","9","10","11","12"
        );
        
        numComboBox = new ComboBox(numberOptions);
        
        
        //Buttons for each section
        Button submitInput1 = new Button("Submit"); //section 1
        submitInput1.setOnAction(new SubmitButtonSection1Handler());
        
        
        Button submitInput2 = new Button("Submit"); //section 2
        submitInput2.setOnAction(new SubmitButtonSection2Handler());
        
        //Create layout containers
        //Section 1 - hbox
        HBox userInputSection1 = new HBox(35, userInput1, submitInput1);
        userInputSection1.setAlignment(Pos.CENTER);
        
        //Comine layouts for section 1
        VBox section1 = new VBox(10,textReadOnly1, userInputSection1);
        section1.setStyle("-fx-padding: 15px; -fx-background-color: #b582c2; "
                + "-fx-alignment: center; -fx-border-color: black");
        section1.setMinWidth(400);
        section1.setMinHeight(125);
        
        //Name section 1 layout for CSS use later
        section1.setId("section-1");
        
        //section 2 - hbox
        HBox userInputSection2 = new HBox(10, numComboBox, monthComboBox, submitInput2);
        userInputSection2.setAlignment(Pos.CENTER);
        
        //Combine layouts for section 2
        VBox section2 = new VBox(10, textReadOnly2, userInputSection2);
        section2.setStyle("-fx-padding: 15px; -fx-background-color: #966ca1; "
                + "-fx-alignment: center; -fx-border-color: black");
        section2.setMinWidth(400);
        section2.setMinHeight(125);
        
        //Name section 2 layout for CSS use later
        section2.setId("section-2");
        
        //Comine sections
        VBox monthDisplayCombined = new VBox(section1, section2);
        
        
        
        //Create menuBar and items.
        Menu fileMenu = new Menu("File");
        Menu helpMenu = new Menu("Help");
        
        MenuItem aboutMenu = new MenuItem("About");
        MenuItem helpOption = new MenuItem("Help");
        MenuItem exitMenu = new MenuItem("Exit");

        fileMenu.getItems().addAll(exitMenu);
        helpMenu.getItems().addAll(aboutMenu, helpOption);

        //Sets up actual fileMenu bar with visible buttons
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(fileMenu, helpMenu);
        
        //Set button functions
        aboutMenu.setOnAction(e -> window.setScene(aboutScreen));
        helpOption.setOnAction(e -> window.setScene(helpScreen));
        exitMenu.setOnAction(e -> {Platform.exit();} );
        
        
        
        //Setup elements for aboutScreen
        Label aboutLabel = new Label("Program Name: Month Selector and Comparison\n" +
                                     "Author: Megan Ostrander");
        aboutLabel.setWrapText(true);
        Button aboutReturnButton = new Button("Return");
        aboutReturnButton.setOnAction(e -> window.setScene(mainProgram));
        
        VBox aboutBox = new VBox(10, aboutLabel, aboutReturnButton);
        aboutBox.setAlignment(Pos.CENTER);
        aboutBox.setStyle("-fx-padding: 20px; -fx-background-color: #FEE0FC");
        aboutScreen = new Scene(aboutBox);
        
        
        //Setup elements of helpScreen
        Label helpLabel = new Label("Top section: Enter the number or name associated with the desired month.\n\n"
                                + "Bottom section: Select two values from the drop down lists to compare months.");
        helpLabel.setWrapText(true);
        Button helpReturnButton = new Button("Return");
        helpReturnButton.setOnAction(e -> window.setScene(mainProgram));
        
        VBox helpBox = new VBox(10, helpLabel, helpReturnButton);
        helpBox.setAlignment(Pos.CENTER);
        helpBox.setStyle("-fx-padding: 20px; -fx-background-color: #FEE0FC");
        helpScreen = new Scene(helpBox);
        
        
        layout = new BorderPane();
        layout.setCenter(monthDisplayCombined);
        layout.setTop(menuBar);
          
        mainProgram = new Scene(layout);
        mainProgram.getStylesheets().add("monthStyles.css");
        
        window.setScene(mainProgram);
        window.show();
        
    }

    public static void main(String[] args) {
        launch();
    }
    
    
    class SubmitButtonSection1Handler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle (ActionEvent event)
        {
            Month monthAttempt1; //Prepare month object
            String input = userInput1.getText(); //Obtain user input
            int numInput = -1; //Invalid input, prepare for number input

            
            if(input.isBlank())
            {
                monthAttempt1 = new Month(); //default constructor
            }
            else
            {
                try
                {
                    //Try to retrieve integer value from string
                    numInput = Integer.parseInt(input);
                    
                    //If that does NOT fail, use the int constructor
                    monthAttempt1 = new Month(numInput);
                    
                }
                catch(Exception e)
                {
                    //Else, use the String constructor
                    monthAttempt1 = new Month(input);
                }
                
            }
            
            
            //Determine if monthAttempt contains a valid input
            if(monthAttempt1.printMonthName() != null)
            {
                textReadOnly1.setText(monthAttempt1.toString());
            }
            else
            {
                textReadOnly1.setText("Unrecognized text entry. "
                        + "Please enter the number or name associated with the desired month.");
            }
            
        }
        
        
    }
    
    
    class SubmitButtonSection2Handler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle (ActionEvent event)
        {
            Month monthSelected1; //Prepare month objects. For int
            Month monthSelected2; //For String
            
            //Get the combobox values selected
            String selectedNum = (String) numComboBox.getValue();
            String selectedMonth = (String)monthComboBox.getValue();
            
            //Verify user selects from both comboboxes.
            if(selectedNum == null || selectedMonth == null)
            {
                textReadOnly2.setText("Invalid selections.");
            }
            else
            {
                try
                {
                  int monthNum = Integer.parseInt(selectedNum);  
                  
                  //Create month objects
                  Month month1 = new Month(monthNum);
                  Month month2 = new Month(selectedMonth);
                  
                  //compare the month values and update read only field.
                  textReadOnly2.setText(month1.monthComparison(month2));
                }
                catch(Exception e)
                {
                    textReadOnly2.setText("Unexpected error occurred.");
                }
 
            }
            
        }
        

    }
    
    
    
}