package ostrander.ostrander_lab5_javafx;

/**
 *
 * @author ostra
 */
public class Month 
{
    private String monthName;
    private int monthNum;
    
    //default constructor
    public Month()
    {
        monthName = "January";
        monthNum = 1;
    }
    
    //Constructors for int and String value passed
    public Month(int value)
    {
        String pass = Integer.toString(value);
        verifyValidInput(pass);
    }
    
    public Month(String value)
    {
        verifyValidInput(value);
    }
    
    
    private void verifyValidInput(String value)
    {
        
        switch(value.toLowerCase())
        {
            case "1":
            case "january":
                monthName = "January";
                monthNum = 1;
                break;
            case "2":
            case "february":
                monthName = "February";
                monthNum = 2;
                break;
            case "3":
            case "march":
                monthName = "March";
                monthNum = 3;
                break;
            case "4":
            case "april":
                monthName = "April";
                monthNum = 4;
                break;
            case "5":
            case "may":
                monthName = "May";
                monthNum = 5;
                break;
            case "6":
            case "june":
                monthName = "June";
                monthNum = 6;
                break;
            case "7":
            case "july":
                monthName = "July";
                monthNum = 7;
                break;
            case "8":
            case "august":
                monthName = "August";
                monthNum = 8;
                break;
            case "9":
            case "september":
                monthName = "September";
                monthNum = 9;
                break;
            case "10":
            case "october":
                monthName = "October";
                monthNum = 10;
                break;
            case "11":
            case "november":
                monthName = "November";
                monthNum = 11;
                break;
            case "12":
            case "december":
                monthName = "December";
                monthNum = 12;
                break;
            default:
                //Invalid value given
                monthName = null;
                break;     
        }


    }
    
    
    public String printMonthName()
    {
        return monthName;
    }
    
    public int getMonthNum()
    {
        return monthNum;
    }
    
    public String toString()
    {
        return monthName + " (" + monthNum + ")";
    }
    
    
    public String monthComparison(Month otherGiven)
    {
        if(monthNum > otherGiven.getMonthNum())
        {
            return monthName + " is greater than " + otherGiven.printMonthName();
        }
        else if(monthNum < otherGiven.getMonthNum())
        {
            return otherGiven.printMonthName() + " is greater than " + monthName;
        }
        else
        {
            return "The months are equal.";
        }
        
    }
    
}
