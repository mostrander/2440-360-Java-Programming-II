module ostrander.ostrander_lab5_javafx {
    requires javafx.controls;
    exports ostrander.ostrander_lab5_javafx;
}
