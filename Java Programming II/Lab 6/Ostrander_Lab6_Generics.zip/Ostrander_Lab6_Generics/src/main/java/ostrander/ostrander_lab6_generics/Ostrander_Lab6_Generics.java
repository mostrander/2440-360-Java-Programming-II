
package ostrander.ostrander_lab6_generics;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author ostra
 */
public class Ostrander_Lab6_Generics {

    public static void main(String[] args) 
    {
        System.out.println("Creating three ArrayLists containing integers, doubles, "
                + "and floats respectively:");
        
        ArrayList<Integer> intList = new ArrayList<>(Arrays.asList(20,15,4,6,86,45));
        ArrayList<Double> doubleList = new ArrayList<>(Arrays.asList(45.2, 12.9, 7.7, 3.0, 16.2, 20.1));
        ArrayList<Float> floatList = new ArrayList<>(Arrays.asList(0.2f, 0.8f, 1.5f, 3.1f, 2.1f, 0.7f));
        
        System.out.println("Each ArrayList has been created with 6 values: ");
        System.out.println("intList values: 20, 15, 4, 6, 86, 45");
        System.out.println("doubleList values: 45.2, 12.9, 7.7, 3.0, 16.2, 20.1");
        System.out.println("floatList values: 0.2, 0.8, 1.5, 3.1, 2.1, 0.7");
        
        
        System.out.println("\nNow, going to create three GenericNumList objects: ");
        GenericNumList<Integer> intGenList = new GenericNumList<>(intList);
        GenericNumList<Double> doubleGenList = new GenericNumList<>(doubleList);
        GenericNumList<Float> floatGenList = new GenericNumList<>(floatList);
        
        
        System.out.println("\nTesting the intGenList with functions: ");
        System.out.println("Maximum value: " + intGenList.maximum() + 
                           "\nMinimum value: " + intGenList.minimum());
        System.out.printf("Average value: %.2f \nTotal value: %.2f", 
                                intGenList.average(), intGenList.total());
        
        
        System.out.println("\n\nTesting the doubleGenList with functions: ");
        System.out.println("Maximum value: " + doubleGenList.maximum() + 
                           "\nMinimum value: " + doubleGenList.minimum());
        System.out.printf("Average value: %.2f \nTotal value: %.2f", 
                                doubleGenList.average(), doubleGenList.total());
        
        
        System.out.println("\n\nTesting the floatGenList with functions: ");
        System.out.println("Maximum value: " + floatGenList.maximum() + 
                           "\nMinimum value: " + floatGenList.minimum());
        System.out.printf("Average value: %.2f \nTotal value: %.2f", 
                                floatGenList.average(), floatGenList.total());
        
        
        
        
    }
    
    
}
