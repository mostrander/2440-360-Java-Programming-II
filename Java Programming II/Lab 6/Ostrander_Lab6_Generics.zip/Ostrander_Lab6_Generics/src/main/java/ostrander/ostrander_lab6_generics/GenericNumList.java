/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ostrander.ostrander_lab6_generics;

import java.util.ArrayList;

/**
 *
 * @author ostra
 * @param <T> Takes in a generic item to create this class, bound by Number class
 */
public class GenericNumList<T extends Number> 
{
    private ArrayList<T> numList;
    
    public GenericNumList (ArrayList<T> listGiven)
    {
        numList = listGiven;
    }
    
    public T maximum()
    {
        T max;
        max = numList.get(0);
        
        for(int x = 0; x < numList.size(); x++)
        {
            if(max.doubleValue() < numList.get(x).doubleValue())
            {
                max = numList.get(x);
            }
        }
        
        return max;
        
    }
    
    
    public <V extends Number> double total()
    {
        double total = 0.0;
        
        if(!numList.isEmpty())
        {
            for(int x = 0; x < numList.size(); x++)
            {
                total = total + numList.get(x).doubleValue();
            } 
        }
        
        return total;
    }
    
    
    public T minimum()
    {
        T min;
        min = numList.get(0);
        
        for(int x = 0; x < numList.size(); x++)
        {
            if(min.doubleValue() > numList.get(x).doubleValue())
            {
                min = numList.get(x);
            }
        }
        
        return min;
    }
    
    
    public <S extends Number> double average()
    {
        double average;
        double total = 0.0;
        int count;
        
        if(!numList.isEmpty())
        {  
            count = numList.size(); // number of elements in list
            
            for(int x = 0; x < numList.size(); x++)
            {
                total = total + numList.get(x).doubleValue();
            } 
            
            average = total / count;

            return average;  
        }
        else
        {
            return 0.0;
        }
        
    }
    
    
}
