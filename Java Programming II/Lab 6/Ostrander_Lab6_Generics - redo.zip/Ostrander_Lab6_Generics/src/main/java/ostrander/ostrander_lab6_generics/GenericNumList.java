/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ostrander.ostrander_lab6_generics;

import java.util.ArrayList;

/**
 *
 * @author ostra
 * @param <T> Takes in a generic item to create this class, bound by Number class
 */
public class GenericNumList<T extends Number> 
{
    private ArrayList<T> numList;
    
    public GenericNumList (ArrayList<T> listGiven)
    {
        numList = listGiven;
    }
    
    public T maximum()
    {
        T max;
        max = numList.get(0);
        
        for(int x = 0; x < numList.size(); x++)
        {
            if(max.doubleValue() < numList.get(x).doubleValue())
            {
                max = numList.get(x);
            }
        }
        
        return max;
        
    }
    
    
    public T total()
    {
        double total = 0.0;
        
        if(!numList.isEmpty())
        {
            for(int x = 0; x < numList.size(); x++)
            {
                total = total + numList.get(x).doubleValue();
            } 
        }
        
        T sum = (T)(Double.valueOf(total));
        
        return sum;
    }
    
    
    public T minimum()
    {
        T min;
        min = numList.get(0);
        
        for(int x = 0; x < numList.size(); x++)
        {
            if(min.doubleValue() > numList.get(x).doubleValue())
            {
                min = numList.get(x);
            }
        }
        
        return min;
    }
    
    
    public T average()
    {
        double average;
        double total = Double.valueOf(0);
        
        if(!numList.isEmpty())
        {  
            
            for(int i = 0; i < numList.size(); i++)
            {
                total = total + numList.get(i).doubleValue();
            }
            
        }

        average = total / Double.valueOf(numList.size());

        T result = (T)(Double.valueOf(average));

        return result;  
        
    }
    
    
}
